# HematoVision: Advanced Blood Cell Classification Using Transfer Learning

This project aims to develop an advanced system for classifying different types of blood cells using deep learning, specifically leveraging the power of transfer learning. This web application provides a user-friendly interface to upload blood cell images and receive classification results, valuable for medical diagnostics.

## Project Structure